define({
  root: {
    widgetTitle: "Trip Distance Calculator" ,
    description: "Calculates what zone each stop is in and the distance to the closest depot."
  }
  // add supported locales below:
  // , "zh-cn": true
});
